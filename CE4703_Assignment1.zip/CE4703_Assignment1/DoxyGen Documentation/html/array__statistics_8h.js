var array__statistics_8h =
[
    [ "countUsedElements", "array__statistics_8h.html#ae2e88ac8d29dfa37e33dd13553765cac", null ],
    [ "getAverage", "array__statistics_8h.html#a29b86644b114d35baca16daacea7f4d1", null ],
    [ "getMaximum", "array__statistics_8h.html#ae4a13df92d8e1a7503bb91b16de072ae", null ],
    [ "getMedian", "array__statistics_8h.html#a63b87f0f15f9ffe55d187bea17d7696c", null ],
    [ "getMinimum", "array__statistics_8h.html#afc85a4c15ca09d11bba5c74f0c5d1f01", null ],
    [ "getStandardDeviation", "array__statistics_8h.html#a762a4df340d008ff7a9aaa83f1f3aa4c", null ],
    [ "getVariance", "array__statistics_8h.html#a1044c3874ce342def032e271dfdc60d1", null ]
];
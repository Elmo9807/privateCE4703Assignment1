var searchData=
[
  ['max_0',['MAX',['../config_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'config.h']]]
];
